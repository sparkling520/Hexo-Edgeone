---
title: Hello World
date: 2025-01-05 17:00:12
categories: 测试
keywords: 测试
tags: 测试
---
Welcome to [Hexo](https://hexo.io/)! This is your very first post. Check [documentation](https://hexo.io/docs/) for more info. If you get any problems when using Hexo, you can find the answer in [troubleshooting](https://hexo.io/docs/troubleshooting.html) or you can ask me on [GitHub](https://github.com/hexojs/hexo/issues).

## Quick Start

### Create a new post

``` bash
$ hexo new "My New Post"
```

More info: [Writing](https://hexo.io/docs/writing.html)

### Run server

``` bash
$ hexo server
```

More info: [Server](https://hexo.io/docs/server.html)

### Generate static files

``` bash
$ hexo generate
```

More info: [Generating](https://hexo.io/docs/generating.html)

### Deploy to remote sites

``` bash
$ hexo deploy
```

More info: [Deployment](https://hexo.io/docs/one-command-deployment.html)



<!-- ============================================================
     PDF 3D 翻书效果 - Hexo 文章嵌入代码
     使用方法：
     1. 把你的 PDF 文件放到 source/pdfs/ 目录下
     2. 把下面这段代码整个粘贴到你的 Markdown 文章里
     3. 修改 PDF_URL 为你的 PDF 文件名（以 / 开头）
     
     依赖库（全部 CDN 自动加载，无需手动安装）：
     - PDF.js v3.11.174  →  渲染 PDF 页面
     - page-flip v2.0.7  →  3D 翻书动画效果
     ============================================================ -->

<!-- ===== 翻书容器 ===== -->
<div class="flipbook-wrapper" id="myFlipbookWrapper">
  <!-- 加载提示 -->
  <div class="flipbook-loading" id="flipbookLoading"
       style="text-align:center;padding:60px 20px;color:#666;font-size:16px;background:#fff;border-radius:8px;">
    📄 正在加载 PDF，请稍候...
  </div>
  <!-- 翻书主体（PDF 渲染后填充到这里） -->
  <div class="flipbook-container" id="flipbookContainer"
       style="display:none;background:#fff;box-shadow:0 4px 20px rgba(0,0,0,0.15);border-radius:4px;overflow:hidden;"></div>
  <!-- 翻页按钮 -->
  <div class="flipbook-controls" id="flipbookControls"
       style="display:none;justify-content:center;gap:16px;margin-top:20px;flex-wrap:wrap;">
    <button onclick="window.myFlipbook && window.myFlipbook.flipPrev()"
            style="padding:10px 24px;background:#1a73e8;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:14px;">
      ⬅ 上一页
    </button>
    <button onclick="window.myFlipbook && window.myFlipbook.flipNext()"
            style="padding:10px 24px;background:#1a73e8;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:14px;">
      下一页 ➡
    </button>
  </div>
  <!-- 页码显示 -->
  <div class="flipbook-page-info" id="flipbookPageInfo"
       style="display:none;text-align:center;margin-top:12px;color:#666;font-size:14px;"></div>
</div>

<!-- ===== JavaScript 核心逻辑 ===== -->
<script>
/* ---- 【必须修改】你的 PDF 文件路径，根相对路径 ---- */
const PDF_URL = '/pdfs/sample.pdf';

/* ---- 动态加载 JS 库（按顺序加载） ---- */
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error('加载失败: ' + src));
    document.head.appendChild(s);
  });
}

/* ---- 主函数：加载库 → 渲染 PDF → 初始化翻书 ---- */
async function initFlipbook() {
  const loadingEl  = document.getElementById('flipbookLoading');
  const containerEl= document.getElementById('flipbookContainer');
  const controlsEl = document.getElementById('flipbookControls');
  const infoEl     = document.getElementById('flipbookPageInfo');

  try {
    // 1. 加载 PDF.js（渲染 PDF 的核心库）
    await loadScript('https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js');
    // 设置 worker 路径（后台线程解析 PDF）
    pdfjsLib.GlobalWorkerOptions.workerSrc =
      'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js';

    // 2. 加载 page-flip（3D 翻书动画库）
    await loadScript('https://cdn.jsdelivr.net/npm/page-flip@2.0.7/dist/js/page-flip.browser.min.js');

    // 3. 加载并渲染 PDF
    const pdf = await pdfjsLib.getDocument(PDF_URL).promise;
    const total = pdf.numPages;

    // 拿第一页的尺寸来设置书本比例
    const page1 = await pdf.getPage(1);
    const vp = page1.getViewport({ scale: 1 });
    const pw = vp.width;
    const ph = vp.height;

    // 设置容器宽高比（桌面端左右两页摊开）
    containerEl.style.aspectRatio = (pw * 2) + ' / ' + ph;
    containerEl.style.width = '100%';
    containerEl.style.maxWidth = '900px';
    containerEl.style.margin = '0 auto';

    // 逐页渲染到 canvas
    const scale = 2; // 2 倍清晰度
    for (let i = 1; i <= total; i++) {
      const page = await pdf.getPage(i);
      const svp = page.getViewport({ scale });

      const pageDiv = document.createElement('div');
      pageDiv.style.cssText = 'width:100%;height:100%;background:#fff;overflow:hidden;';

      const canvas = document.createElement('canvas');
      canvas.width = svp.width;
      canvas.height = svp.height;
      canvas.style.cssText = 'width:100%;height:100%;display:block;';
      pageDiv.appendChild(canvas);
      containerEl.appendChild(pageDiv);

      await page.render({
        canvasContext: canvas.getContext('2d'),
        viewport: svp
      }).promise;

      loadingEl.innerHTML = `📄 正在渲染第 ${i} / ${total} 页...`;
    }

    // 4. 初始化翻书效果
    const PF = window.PageFlip || (window.St && window.St.PageFlip);
    if (!PF) throw new Error('page-flip 库加载失败');

    const flipbook = new PF(containerEl, {
      width: pw,
      height: ph,
      size: 'stretch',          // 自适应容器宽度
      minWidth: 300,
      maxWidth: 1000,
      minHeight: 400,
      maxHeight: 800,
      drawShadow: true,         // 翻页阴影（更真实）
      flippingTime: 800,        // 翻页动画时长(毫秒)
      usePortrait: true,        // 手机竖屏自动单页模式
      startPage: 0,
      clickEventForward: true,  // 点击翻页
      showCover: true,          // 封面单页显示
      mobileScrollSupport: true,// 手机触摸滑动翻页
      swipeDistance: 50,
    });

    flipbook.loadFromHTML(containerEl.children);
    window.myFlipbook = flipbook; // 挂到全局供按钮调用

    // 页码更新
    flipbook.on('flip', (e) => {
      infoEl.textContent = `第 ${e.data + 1} 页 / 共 ${total} 页`;
    });

    // 显示翻书，隐藏加载提示
    loadingEl.style.display = 'none';
    containerEl.style.display = 'block';
    controlsEl.style.display = 'flex';
    infoEl.style.display = 'block';
    infoEl.textContent = `第 1 页 / 共 ${total} 页`;

  } catch (err) {
    loadingEl.innerHTML = '❌ 加载失败：' + err.message +
      '<br>请检查 PDF 路径是否正确，或网络是否能访问 CDN';
    console.error(err);
  }
}

// 页面加载完成后启动
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initFlipbook);
} else {
  initFlipbook();
}
</script>

<!-- ===== 嵌入代码结束 ===== -->
